const s=1;function c(e,r){var o;let t=0;for(const i of r){const n=(o=i.attributes)==null?void 0:o[e];typeof n=="number"&&isFinite(n)&&(t=Math.max(t,n))}return t}export{c as n,s as t};
