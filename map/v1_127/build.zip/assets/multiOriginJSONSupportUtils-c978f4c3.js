function i(n){return n&&"getAtOrigin"in n&&"originOf"in n}export{i};
