import{O as t}from"./geometryEngineJSON-534b66aa.js";import"./index-eed032b4.js";import"./json-48e3ea08.js";function i(r){return(0,t[r.operation])(...r.parameters)}export{i as executeGEOperation};
