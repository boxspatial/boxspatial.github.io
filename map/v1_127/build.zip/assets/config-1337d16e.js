const o=!0,t=32,c=1.5,e=200;export{c,e,o,t};
