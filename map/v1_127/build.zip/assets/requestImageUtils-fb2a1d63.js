import{G as n}from"./index-eed032b4.js";async function r(a,t){const{data:e}=await n(a,{responseType:"image",...t});return e}export{r as t};
