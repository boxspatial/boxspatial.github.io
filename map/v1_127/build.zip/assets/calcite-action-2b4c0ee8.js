import{A as t,d as o}from"./action-76209c8b.js";import"./index-eed032b4.js";import"./guid-0d265cb2.js";import"./loader-9caa63c1.js";import"./loadable-1d902631.js";import"./t9n-a72cb84e.js";import"./observers-279029a9.js";import"./icon-beecf407.js";/*!
 * All material copyright ESRI, All Rights Reserved, unless otherwise specified.
 * See https://github.com/Esri/calcite-design-system/blob/main/LICENSE.md for details.
 * v1.9.1
 */const a=t,d=o;export{a as CalciteAction,d as defineCustomElement};
