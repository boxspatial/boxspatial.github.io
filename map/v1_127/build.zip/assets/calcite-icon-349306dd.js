import{I as o,d as t}from"./icon-beecf407.js";import"./index-eed032b4.js";import"./observers-279029a9.js";/*!
 * All material copyright ESRI, All Rights Reserved, unless otherwise specified.
 * See https://github.com/Esri/calcite-design-system/blob/main/LICENSE.md for details.
 * v1.9.1
 */const i=o,s=t;export{i as CalciteIcon,s as defineCustomElement};
